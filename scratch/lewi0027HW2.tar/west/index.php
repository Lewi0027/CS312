<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>West</title>
        <link rel="icon" href="../images/SMPTE.png" type="image/png">
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta name="author" content="Henry Lewis">
        <meta name="description" content="CS312 West website">
        <meta name="keywords" content="West">
    </head>
    <?php 
        include ('nav.php');
    ?>
    <body class="pagerules">
        <h3>Lorem Ipsum</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget sapien bibendum, dictum leo a, volutpat augue. Vestibulum dictum, risus eget fringilla elementum, leo urna semper ante, eget mattis eros mi ac lorem. Suspendisse aliquet, quam in faucibus molestie, dui ante egestas nibh, nec volutpat elit eros a velit. Nam eu magna tempus, laoreet lacus nec, tempor ligula. Aenean fringilla malesuada dui vitae auctor. Praesent efficitur dui at tincidunt placerat. Proin elementum massa at tortor consequat, non aliquet ante ultricies.</p>
        <p>Aliquam placerat magna ut nibh cursus, id luctus diam ornare. Pellentesque nec egestas nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur non diam nec dui consequat efficitur. Nunc imperdiet viverra tincidunt. Phasellus iaculis sapien a aliquam viverra. Cras non tristique ante, id sagittis dui. Integer mollis mollis dictum. Vestibulum gravida eleifend lorem in tempor. Morbi sodales venenatis iaculis. Curabitur a ante vulputate, sodales ligula vitae, ullamcorper est. Aenean nec nulla ornare, fermentum odio nec, fermentum nisi. Nullam vitae leo in lacus fermentum feugiat fringilla vel arcu. Quisque commodo, mauris nec tincidunt semper, sem est convallis elit, placerat mattis felis odio eu risus.</p>
    </body>
    <body>
        <h1>West</h1>
        <p><img src="../images/picofme.png"alt="picofme">
        <p>by: Henry Lewis</p>
        <p>CS 312 SP2024</p>
    </body>
    <footer>
        <p>Last updated: 2/18/24</p>
    </footer>
</html>
